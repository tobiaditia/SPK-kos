@extends('layouts.app_admin_lte')

@section('content')
    <div class="card">
        <div class="card-header">
            <h3 class="card-title">Detail Data Kos</h3>
        </div>
        <div class="card-body">
            
        </div>
    </div>
@endsection
